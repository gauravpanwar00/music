var express = require('express');
var router = express.Router();
var nodemailer = require('nodemailer');
var transport = nodemailer.createTransport({
  host: "smtp-relay.sendinblue.com",
  port: 587,
  tls: {
    rejectUnauthorized: true,
    minVersion: "TLSv1.2"
  },
  auth: {
    user: process.env.mailID,
    pass: process.env.mailKey
  }
});

const music = {
  dholak: {
    title: 'Dholak',
    videos: ['https://www.youtube.com/embed/KR08DKUP70I', 'https://www.youtube.com/embed/qXVKYC7Zwlk', 'https://www.youtube.com/embed/U-G-IX6Z2pc', 'https://www.youtube.com/embed/nyJQDhKX1rE', 'https://www.youtube.com/embed/3R-QP0lGXAI', 'https://www.youtube.com/embed/gXk0xuaizOY', 'https://www.youtube.com/embed/Mi6wYF5h7o8', 'https://www.youtube.com/embed/op09H027SdM', 'https://www.youtube.com/embed/viwxrS6rM1Y', 'https://www.youtube.com/embed/WKpuFfUyi6g'],
  },
  tabla: {
    title: 'Tabla',
    videos: ['https://www.youtube.com/embed/SaZmBbGb1LI', 'https://www.youtube.com/embed/w99VI0KE20A', 'https://www.youtube.com/embed/SfSm0M8h5_E', 'https://www.youtube.com/embed/EW6kURLkinI', 'https://www.youtube.com/embed/lFlk92OoqUI', 'https://www.youtube.com/embed/ceu2QXojfFA', 'https://www.youtube.com/embed/0Wx_fnk5Aks'],
  },
  harmonium: {
    title: 'Harmonium',
    videos: ['https://www.youtube.com/embed/S7zhIC520sI', 'https://www.youtube.com/embed/fBUjNqghDSs', 'https://www.youtube.com/embed/TZ3sdcmAdGU', 'https://www.youtube.com/embed/bLsK3JGDaVs', 'https://www.youtube.com/embed/iva9F1Mz_zo', 'https://www.youtube.com/embed/G1U2zpb7ogI', 'https://www.youtube.com/embed/4tDW0xjSEv8', 'https://www.youtube.com/embed/KC7rbGi2vg8', 'https://www.youtube.com/embed/C2IYgsdVWEs'],
  },
  guitar: {
    title: 'Guitar',
    videos: ['https://www.youtube.com/embed/BBz-Jyr23M4', 'https://www.youtube.com/embed/5rcCiXqAShY', 'https://www.youtube.com/embed/w-Zt5Kbf3TM', 'https://www.youtube.com/embed/wAfbTvEeMmw', 'https://www.youtube.com/embed/rTMN8rCBWkw'],
  }
}

/* GET home page. */
router.get('/', function (req, res, next) {
  res.render('index', { title: 'Express' });
});

router.post('/query', (req, res) => {

  const { email, name, message } = req.body;


  transport.sendMail({
    from: 'sangitagya@music.acadmy',
    to: 'akshatsoni8055@gmail.com',
    subject: 'Your Query has been submitted Successfully',
    html: `name: <b>${name}</b> <br/>
    email: <b>${email}</b> <br/>
    message: <b>${message}</b> <br/>`,
  }, (err, info) => {
    if (err) return res.render('error');
    return res.render('index');
  });

})

router.get('/music', (req, res) => {
  res.render('music', music[req.query.category]);
})

module.exports = router;
